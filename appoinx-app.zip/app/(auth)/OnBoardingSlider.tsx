import {
  FlatList,
  Image,
  Pressable,
  StyleSheet,
  Text,
  View,
  ViewToken,
  Dimensions,
} from "react-native";
import React, { useEffect } from "react";
import { onbordingSliderData } from "@/constants/data";
import OnBoardingSliderItem, { ItemProps } from "@/components/ui/OnBoardingSliderItem";
import { SafeAreaView } from "react-native-safe-area-context";
import Animated, {
  useAnimatedRef,
  useAnimatedScrollHandler,
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withRepeat,
  withSequence,
  Easing,
} from "react-native-reanimated";
import Pagination from "@/components/ui/Pagination";
import SliderButton from "@/components/ui/SliderButton";
import { router } from "expo-router";
import img1 from "@/assets/images/2.png";
import img2 from "@/assets/images/4.png";
import img3 from "@/assets/images/1.png";
import img4 from "@/assets/images/1.png";
import img5 from "@/assets/images/3.png";

const { width, height } = Dimensions.get("window");

const OnBoardingSlider = () => {
  const flatListRef = useAnimatedRef<FlatList<ItemProps>>();
  const x = useSharedValue(0);
  const flatListIndex = useSharedValue(0);

  // 🚀 Define shared values for animation
  const translateY1 = useSharedValue(0);
  const translateY2 = useSharedValue(0);

  // 🚀 Start animation on mount
  useEffect(() => {
    translateY1.value = withRepeat(
      withSequence(
        withTiming(-10, { duration: 3000, easing: Easing.linear }),
        withTiming(10, { duration: 3000, easing: Easing.linear })
      ),
      -1, // Infinite loop
      true
    );

    translateY2.value = withRepeat(
      withSequence(
        withTiming(10, { duration: 4000, easing: Easing.linear }),
        withTiming(-10, { duration: 4000, easing: Easing.linear })
      ),
      -1, // Infinite loop
      true
    );
  }, []);

  // 🚀 Apply animation styles
  const animatedStyle1 = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY1.value }],
  }));

  const animatedStyle2 = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY2.value }],
  }));

  const onViewableItemsChanged = ({ viewableItems }: { viewableItems: ViewToken[] }) => {
    if (viewableItems[0].index !== null) {
      flatListIndex.value = viewableItems[0].index;
    }
  };

  const onScroll = useAnimatedScrollHandler({
    onScroll: (event) => {
      x.value = event.contentOffset.x;
    },
  });

  return (
    <View className="bg-primaryColor">
      {/* 🚀 Animated Background Images */}
      <View className="absolute pt-8 w-full">
        <View className="flex-row justify-between items-start w-full px-6">
          <View className="gap-4">
            <Animated.Image
              source={img1}
              style={[styles.image, animatedStyle1]}
            />
            <Animated.Image
              source={img2}
              style={[styles.image, animatedStyle2]}
            />
            <Animated.Image
              source={img3}
              style={[styles.image, animatedStyle1]}
            />
          </View>
          <View className="gap-4">
            <Animated.Image
              source={img4}
              style={[styles.image, animatedStyle2]}
            />
            <Animated.Image
              source={img5}
              style={[styles.image, animatedStyle1]}
            />
            <Animated.Image
              source={img1}
              style={[styles.image, animatedStyle2]}
            />
          </View>
        </View>
      </View>

      {/* 🚀 Main Content */}
      <View className="justify-end items-center h-full">
        <View className="bg-blackColor max-h-[300px] flex-1 rounded-t-3xl ">
          <Animated.FlatList
            ref={flatListRef}
            data={onbordingSliderData}
            onScroll={onScroll}
            keyExtractor={(item) => `key:${item.id}`}
            renderItem={({ item, index }) => <OnBoardingSliderItem item={item} idx={index} />}
            scrollEventThrottle={16}
            horizontal
            bounces={false}
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onViewableItemsChanged={onViewableItemsChanged}
            viewabilityConfig={{
              minimumViewTime: 300,
              viewAreaCoveragePercentThreshold: 10,
            }}
          />

          {/* Pagination and Button */}
          <View className="py-7">
            <Pagination onbordingSliderData={onbordingSliderData} x={x} />
          </View>
          <View className="flex justify-between items-center flex-row px-6">
            <Pressable onPress={() => router.push("/SignIn")}>
              <Text className="font-semibold text-secondaryBg">דלג</Text>
            </Pressable>
            <SliderButton
              flatListRef={flatListRef}
              flatListIndex={flatListIndex}
              dataLength={onbordingSliderData.length}
              x={x}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

export default OnBoardingSlider;

const styles = StyleSheet.create({
  image: {
    maxHeight: 180,
    maxWidth: 160,
    borderRadius: 20,
  },
});
