import React, { useState, useRef, useEffect } from "react";
import {
  TextInput,
  Text,
  View,
  Alert,
  TouchableOpacity,
  ActivityIndicator,
  ImageBackground,
  Keyboard,
  TouchableWithoutFeedback,
  Animated,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useAuth } from "../../context/AuthContext";
import { useNavigation } from "expo-router";
import LottieView from "lottie-react-native"; // ✅ Lottie for animation

const VerifyOTP = () => {
  const { confirmation } = useAuth();
  const navigation = useNavigation();
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const inputRefs = useRef([]);
  const slideAnim = useRef(new Animated.Value(300)).current; // ✅ Animation for bottom sheet

  useEffect(() => {
    if (!confirmation) {
      console.log("🚨 No confirmation object found, redirecting...");
      navigation.replace("/(auth)/SignIn");
    }

    // ✅ Slide-in animation for OTP form
    Animated.timing(slideAnim, {
      toValue: 0,
      duration: 400,
      useNativeDriver: true,
    }).start();
  }, []);

  const handleOtpChange = (value, index) => {
    let newOtp = [...otp];
    newOtp[index] = value;

    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    setOtp(newOtp);

    if (index === 5 && value) {
      console.log("🚀 Auto-submitting OTP...");
      confirmCode(newOtp.join(""));
    }
  };

  const confirmCode = async (enteredOtp) => {
    try {
      setLoading(true);
      console.log("🔢 Verifying OTP:", enteredOtp);

      await confirmation.confirm(enteredOtp);
      console.log("✅ User signed in successfully");
      Alert.alert("Success", "You are now signed in!");

      navigation.replace("(tabs)");
    } catch (error) {
      console.log("❌ Error verifying OTP:", error);
      Alert.alert("Error", "Invalid OTP. Try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
      
          {/* ✅ Animated Bottom Sheet - Centered */}
          <Animated.View
            style={{ transform: [{ translateY: slideAnim }] }}
          >
            {/* ✅ Lottie Animation for Verification */}
            <View className="flex items-center mb-4">
              <LottieView
                source={require("../../assets/animations/otp-verification.json")}
                autoPlay
                loop={false}
                style={{ width: 100, height: 100 }}
              />
            </View>

            <Text className="text-xl font-bold text-center">הכנס קוד</Text>
            <Text className="text-[14px] text-gray-500 text-center pt-2">
              הזן את הקוד בן 6 הספרות שנשלח אליך
            </Text>

            {/* ✅ OTP Inputs - Centered */}
            <View className="flex-row justify-center gap-2 pt-6">
              {otp.map((digit, index) => (
                <TextInput
                  key={index}
                  ref={(ref) => (inputRefs.current[index] = ref)}
                  className="border border-gray-300 text-center text-2xl rounded-lg p-3 w-14 bg-gray-100"
                  keyboardType="number-pad"
                  maxLength={1}
                  value={digit}
                  onChangeText={(value) => handleOtpChange(value, index)}
                  onKeyPress={({ nativeEvent }) => {
                    if (nativeEvent.key === "Backspace" && index > 0) {
                      inputRefs.current[index - 1]?.focus();
                    }
                  }}
                />
              ))}
            </View>

            {/* ✅ Verify Button */}
            <View className="pt-6">
              <TouchableOpacity
                onPress={() => confirmCode(otp.join(""))}
                className="bg-black rounded-lg py-3 w-full flex flex-row justify-center items-center"
                disabled={loading}
              >
                {loading ? (
                  <ActivityIndicator color="white" size="small" />
                ) : (
                  <Text className="text-white text-center font-semibold text-lg">
                    כניסה
                  </Text>
                )}
              </TouchableOpacity>
            </View>

            {/* ✅ Resend Code */}
            <View className="pt-4">
              <Text className="text-sm text-center text-gray-500">
                לא הגיע קוד?{" "}
                <Text className="text-black font-bold">לחץ לשליחה חוזרת</Text>
              </Text>
            </View>
          </Animated.View>
      </TouchableWithoutFeedback>
  );
};

export default VerifyOTP;
