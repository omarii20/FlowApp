import React, { useState, useRef, useEffect } from "react";
import {
  TextInput,
  Text,
  View,
  TouchableOpacity,
  ActivityIndicator,
  Keyboard,
  Animated,
  Image,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNavigation } from "expo-router";
import LottieView from "lottie-react-native";
import auth from "@react-native-firebase/auth";
import { useAuth } from "../../context/AuthContext";
import { KeyboardAvoidingView, Platform, ScrollView } from "react-native";

const SignIn = () => {
  const { setConfirmation } = useAuth();
  const navigation = useNavigation();

  // **State Management**
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const [step, setStep] = useState(1);
  const [timer, setTimer] = useState(60);
  const [isResendDisabled, setResendDisabled] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");
  const [showError, setShowError] = useState(false);
  const [errorCountdown, setErrorCountdown] = useState(10);

  // **Refs**
  const inputRefs = useRef([]);
  const slideAnim = useRef(new Animated.Value(200)).current; // OTP Slide Animation
  const errorSlideAnim = useRef(new Animated.Value(800)).current; // Error Slide Animation

  // **Slide OTP View Up**
  useEffect(() => {
    if (step === 2) {
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 200,
        useNativeDriver: true,
      }).start();
      startCountdown();
    }
  }, [step]);

  // **Show Error Popup & Auto Close**
  const triggerErrorPopup = (message) => {
    setErrorMessage(message);
    setShowError(true);
    setErrorCountdown(10);

    Animated.timing(errorSlideAnim, {
      toValue: 0,
      duration: 300,
      useNativeDriver: true,
    }).start();

    const interval = setInterval(() => {
      setErrorCountdown((prev) => {
        if (prev === 1) {
          closeErrorPopup();
          clearInterval(interval);
        }
        return prev - 1;
      });
    }, 1000);
  };

  // **Close Error Popup**
  const closeErrorPopup = () => {
    Animated.timing(errorSlideAnim, {
      toValue: 800,
      duration: 300,
      useNativeDriver: true,
    }).start(() => setShowError(false));
  };

  // **Start Countdown Timer for Resend OTP**
  const startCountdown = () => {
    setResendDisabled(true);
    let countdown = 60;
    setTimer(countdown);
    const interval = setInterval(() => {
      countdown--;
      setTimer(countdown);
      if (countdown === 0) {
        setResendDisabled(false);
        clearInterval(interval);
      }
    }, 1000);
  };

  // **Format Phone Number**
  const formatPhoneNumber = (input) => {
    let number = input.replace(/\D/g, "");
    if (number.startsWith("0")) {
      number = "+972" + number.substring(1);
    } else if (!number.startsWith("+")) {
      number = "+" + number;
    }
    return number;
  };

  // **Send OTP**
  const sendVerification = async () => {
    if (!phoneNumber) {
      return triggerErrorPopup("אנא הכנס מספר טלפון.");
    }

    const formattedNumber = formatPhoneNumber(phoneNumber);
    if (!/^\+\d{11,12}$/.test(formattedNumber)) {
      return triggerErrorPopup("מספר טלפון לא תקין.");
    }

    try {
      setLoading(true);
      const confirmationResult = await auth().signInWithPhoneNumber(formattedNumber);
      setConfirmation(confirmationResult);
      setStep(2);
    } catch (error) {
      triggerErrorPopup("לא ניתן לשלוח קוד, נסה שוב מאוחר יותר.");
    } finally {
      setLoading(false);
    }
  };

  // **Handle OTP Input Change**
  const handleOtpChange = (value, index) => {
    let newOtp = [...otp];
    newOtp[index] = value;

    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
    setOtp(newOtp);

    if (index === 5 && value) {
      confirmCode(newOtp.join(""));
    }
  };

  // **Confirm OTP**
  const confirmCode = async (enteredOtp) => {
    try {
      setLoading(true);
      await confirmation.confirm(enteredOtp);
      navigation.replace("(tabs)");
    } catch (error) {
      triggerErrorPopup("קוד שגוי, נסה שנית.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView className="flex-1 bg-black">
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} className="flex-1">
        <ScrollView contentContainerStyle={{ flexGrow: 1 }} keyboardShouldPersistTaps="handled">
          <View className="flex-1 justify-center items-center">
            {/* ✅ LOGO */}
            <Image source={require("../../assets/images/logo.png")} style={{ width: 300, height: 120, marginBottom: 20 }} resizeMode="contain" />

            {/* ✅ Phone Number Step */}
            {step === 1 && (
              <View className="bg-gray-900 px-6 py-6 rounded-3xl shadow-lg w-5/6">
                <Text className="text-xl font-bold text-center text-white">כניסה</Text>
                <Text className="text-[14px] text-gray-400 text-center pt-2">הזן את מספר הטלפון שלך</Text>

                <TextInput
                  value={phoneNumber}
                  onChangeText={setPhoneNumber}
                  placeholder="052 123 4567"
                  keyboardType="phone-pad"
                  className="border border-gray-600 rounded-lg p-3 text-lg w-full my-4 text-white"
                  placeholderTextColor="gray"
                />

                <TouchableOpacity
                  onPress={sendVerification}
                  className="bg-gray-700 rounded-lg py-3 w-full flex flex-row justify-center items-center"
                  disabled={loading}
                >
                  {loading ? <ActivityIndicator color="white" size="small" /> : <Text className="text-white text-center font-semibold text-lg">שלח קוד</Text>}
                </TouchableOpacity>
              </View>
            )}

            {/* ✅ OTP Verification Step - Animated Slide Up */}
            {step === 2 && (
              <Animated.View className="px-6 py-6 rounded-3xl shadow-lg w-5/6" style={{ transform: [{ translateY: slideAnim }] }}>
                <View className="flex items-center mb-4">
                  <LottieView source={require("../../assets/animations/otp-verification.json")} autoPlay loop={false} style={{ width: 100, height: 100 }} />
                </View>
                <Text className="text-xl font-bold text-center text-white">הכנס קוד</Text>
                <Text className="text-[14px] text-gray-400 text-center pt-2">הזן את הקוד בן 6 הספרות שנשלח אליך</Text>
              </Animated.View>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      {/* ✅ Full-Screen Error Popup */}
      {showError && (
        <Animated.View className="absolute inset-0 bg-black bg-opacity-90 flex items-center justify-center" style={{ transform: [{ translateY: errorSlideAnim }] }}>
          <TouchableOpacity onPress={closeErrorPopup} className="absolute top-5 right-5">
            <Text className="text-white text-2xl">✖</Text>
          </TouchableOpacity>
          <LottieView source={require("../../assets/animations/Animation-error.json")} autoPlay loop={false} style={{ width: 150, height: 150 }} />
          <Text className="text-white text-lg font-bold mt-4">{errorMessage}</Text>
        </Animated.View>
      )}
    </SafeAreaView>
  );
};

export default SignIn;
