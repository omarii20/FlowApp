import { StyleSheet } from "react-native";
import React from "react";
import OnBoardingSlider from "./(auth)/OnBoardingSlider";

const index = () => {
  return <OnBoardingSlider />;
};

export default index;

const styles = StyleSheet.create({});
