import { View, StatusBar, Platform, ImageBackground } from "react-native";
import { Slot, SplashScreen, Stack } from "expo-router";
import { useFonts } from "expo-font";
import { useEffect, useState } from "react";
import { SafeAreaView } from "react-native-safe-area-context";
import { AuthProvider } from "../context/AuthContext"; // ✅ Import Auth Context
import Toast from "react-native-toast-message"; // ✅ Import Toast
import * as Notifications from "expo-notifications";
import { registerForPushNotificationsAsync, setupPushNotificationListeners, getFCMToken } from "../config/firebaseConfig";
import "../global.css";

// Prevent auto-hiding splash screen
SplashScreen.preventAutoHideAsync();

const RootLayout = () => {
  const [fontsLoaded, error] = useFonts({
    "Poppins-Black": require("../assets/fonts/Poppins-Black.ttf"),
    "Poppins-Bold": require("../assets/fonts/Poppins-Bold.ttf"),
    "Poppins-ExtraBold": require("../assets/fonts/Poppins-ExtraBold.ttf"),
    "Poppins-ExtraLight": require("../assets/fonts/Poppins-ExtraLight.ttf"),
    "Poppins-Light": require("../assets/fonts/Poppins-Light.ttf"),
    "Poppins-Medium": require("../assets/fonts/Poppins-Medium.ttf"),
    "Poppins-Regular": require("../assets/fonts/Poppins-Regular.ttf"),
    "Poppins-SemiBold": require("../assets/fonts/Poppins-SemiBold.ttf"),
    "Poppins-Thin": require("../assets/fonts/Poppins-Thin.ttf"),
  });

  const [expoPushToken, setExpoPushToken] = useState("");
  useEffect(() => {
    if (expoPushToken) {
      console.log("🔑 Expo Push Token:", expoPushToken);
    }
  }, [expoPushToken]);
  
  // ✅ Initialize Firebase Notifications
  useEffect(() => {
    if (error) throw error;
    if (fontsLoaded) SplashScreen.hideAsync();

    const initializeNotifications = async () => {
      console.log("🚀 Initializing Notifications...");

      // ✅ Get Expo Push Token
      const expoToken = await registerForPushNotificationsAsync();
      setExpoPushToken(expoToken || "Failed to get token");
      console.log("🔑 Expo Push Token:", expoToken);

      // ✅ Get FCM Token (only applicable if using Firebase)
      const fcmToken = await getFCMToken();
      console.log("🔑 FCM Token:", fcmToken);
    };

    initializeNotifications();
    setupPushNotificationListeners();
  }, [fontsLoaded, error]);

  if (!fontsLoaded && !error) return null;

  return (
    <AuthProvider>
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.container}>
          <Stack>
            {/* ✅ Auth Screens */}
            <Stack.Screen name="(auth)/SignIn" options={{ headerShown: false }} />
            <Stack.Screen name="(auth)/SignUp" options={{ headerShown: false }} />
            <Stack.Screen name="(auth)/OnBoardingSlider" options={{ headerShown: true }} />
            <Stack.Screen name="(auth)/VerifySuccessfully" options={{ headerShown: false }} />
            <Stack.Screen name="(auth)/ForgetPassword" options={{ headerShown: false }} />
            <Stack.Screen name="(auth)/VerifyOTP" options={{ headerShown: false }} />

            {/* ✅ Main App Screens */}
            <Stack.Screen name="index" options={{ headerShown: false }} />
            <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
            <Stack.Screen name="(user)" options={{ headerShown: false }} />
            <Stack.Screen name="(screens)" options={{ headerShown: false }} />
          </Stack>

         
        </View>
      </SafeAreaView>

      {/* ✅ Global Toast Component */}
      <Toast />
    </AuthProvider>
  );
};

export default RootLayout;

const styles = {
  safeArea: {
    flex: 1,
    backgroundColor: "#121212",
  },
  container: {
    flex: 1,
  },
};
