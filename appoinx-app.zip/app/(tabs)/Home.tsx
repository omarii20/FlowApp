import React, { useState, useRef } from 'react';
import { Animated, StyleSheet, View, Platform } from 'react-native';
import Header from '@/components/homePage/Header';
import TopDoctor from '@/components/homePage/TopDoctor';
import NotificationModal from '@/components/homePage/modal/NotificationModal';
import FilterModal from '@/components/homePage/modal/FilterModal';
import FavouriteModal from '@/components/homePage/modal/FavouriteModal';
import BackToTopButton from '@/components/homePage/BackToTopButton';

const Home = () => {
  const [showNotification, setShowNotification] = useState(false);
  const [showFilter, setShowFilter] = useState(false);
  const [showFavouriteModal, setShowFavouriteModal] = useState(false);

  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current; // Button fade animation
  const scrollViewRef = useRef(null);

  // Update fadeAnim based on scrollY
  scrollY.addListener(({ value }) => {
    fadeAnim.setValue(value > 100 ? 1 : 0); // Show button after scrolling 100px
  });

  const scrollToTop = () => {
    scrollViewRef.current?.scrollTo({ y: 0, animated: true });
  };

  return (
    <View style={{ flex: 1 }}>
      <Animated.ScrollView
        ref={scrollViewRef}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
      >
        <View style={styles.content}>
          <Header
            setShowNotification={setShowNotification}
            setShowFavouriteModal={setShowFavouriteModal}
          />
          <TopDoctor />
        </View>
      </Animated.ScrollView>

      {/* Back to Top Button */}
      <BackToTopButton fadeAnim={fadeAnim} onPress={scrollToTop} />

      {/* Modals */}
      <NotificationModal
        showNotification={showNotification}
        setShowNotification={setShowNotification}
      />
      <FilterModal showFilter={showFilter} setShowFilter={setShowFilter} />
      <FavouriteModal
        showFavouriteModal={showFavouriteModal}
        setShowFavouriteModal={setShowFavouriteModal}
      />
    </View>
  );
};

export default Home;

const styles = StyleSheet.create({
  content: {
    flex: 1,
  },
});
