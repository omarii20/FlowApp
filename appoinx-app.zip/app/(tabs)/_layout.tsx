import { StyleSheet, View, Text, Platform } from "react-native";
import React from "react";
import { Tabs } from "expo-router";
import { SafeAreaView } from "react-native-safe-area-context";
import Entypo from "@expo/vector-icons/Entypo";
import { AntDesign, MaterialCommunityIcons } from "@expo/vector-icons";

const TabLayout = () => {
  return (
      <Tabs
        screenOptions={{
          tabBarShowLabel: false,
          tabBarStyle: styles.tabBar,
          headerStyle: {
            backgroundColor: "#e9e9e9",
            height: Platform.OS === "ios" ? 100 : 60, // ✅ Fixes iOS header issue
          },
          headerTitleAlign: "center",
        }}
      >
        <Tabs.Screen
          name="Home"
          options={{
            headerShown: false, // ✅ Set false because we handle the header inside Home.tsx
            tabBarIcon: ({ focused }) => (
              <View style={[styles.iconContainer, focused && styles.activeTab]}>
                <Entypo name="home" size={25} color={focused ? "#000" : "#757575"} />
                <Text style={[styles.tabLabel, focused && styles.activeLabel]}>בית</Text>
              </View>
            ),
          }}
        />
        <Tabs.Screen
          name="Chat"
          options={{
            headerShown: false,
            tabBarIcon: ({ focused }) => (
              <View style={[styles.iconContainer, focused && styles.activeTab]}>
                <AntDesign name="message1" size={25} color={focused ? "#000" : "#757575"} />
                <Text style={[styles.tabLabel, focused && styles.activeLabel]}>צ'אט</Text>
              </View>
            ),
          }}
        />
        <Tabs.Screen
          name="MyAppoinment"
          options={{
            headerShown: false,
            tabBarIcon: ({ focused }) => (
              <View style={[styles.iconContainer, focused && styles.activeTab]}>
                <MaterialCommunityIcons
                  name="calendar-check-outline"
                  size={25}
                  color={focused ? "#000" : "#757575"}
                />
                <Text style={[styles.tabLabel, focused && styles.activeLabel]}>תורים</Text>
              </View>
            ),
          }}
        />
        <Tabs.Screen
          name="ProfileTab"
          options={{
            headerShown: false,
            tabBarIcon: ({ focused }) => (
              <View style={[styles.iconContainer, focused && styles.activeTab]}>
                <AntDesign name="user" size={25} color={focused ? "#000" : "#757575"} />
                <Text style={[styles.tabLabel, focused && styles.activeLabel]}>פרופיל</Text>
              </View>
            ),
          }}
        />
      </Tabs>
  );
};

export default TabLayout;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#000000",
  },
  tabBar: {
    backgroundColor: "#FFF",
    height: Platform.OS === "android" ? 50 : 60,
    borderTopWidth: 0,
    elevation: 10, // Increase for stronger shadow on Android
    shadowColor: "#cbcbcb", // Darker shadow color for better visibility
    shadowOpacity: 0.2, // Make the shadow more visible
    shadowRadius: 4, // Softens the shadow edges
    shadowOffset: { width: 0, height: -5 }, // Move shadow **upwards** from the top
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-around",
    paddingTop: 10,
  },  
  iconContainer: {
    alignItems: "center",
    justifyContent: "center",
    width: 50,
    height: 60,
  },
  tabLabel: {
    fontSize: 11,
    color: "#757575",
    marginTop: 3,
  },
  activeLabel: {
    color: "#000",
  },
});
