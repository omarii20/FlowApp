import React from "react";

function HomeSlider() {
  return <div>HomeSlider</div>;
}

export default HomeSlider;
