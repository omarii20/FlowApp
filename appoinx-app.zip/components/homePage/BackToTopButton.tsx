import React from 'react';
import { Animated, TouchableOpacity, StyleSheet } from 'react-native';
import { AntDesign } from '@expo/vector-icons';

const BackToTopButton = ({ fadeAnim, onPress }) => (
  <Animated.View style={[styles.container, { opacity: fadeAnim }]}>
    <TouchableOpacity style={styles.button} onPress={onPress}>
      <AntDesign name="upcircle" size={40} color="#0866ff" />
    </TouchableOpacity>
  </Animated.View>
);

export default BackToTopButton;

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 40,
    right: 20,
    zIndex: 100,
  },
  button: {
    backgroundColor: 'white',
    borderRadius: 25,
    padding: 5,
    elevation: 5, // Shadow for Android
    shadowColor: '#000', // Shadow for iOS
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 3 },
  },
});
