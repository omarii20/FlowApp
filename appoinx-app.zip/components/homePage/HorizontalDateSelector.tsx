import React, { useState, useEffect, useRef } from "react";
import { View, Text, Pressable, FlatList, Dimensions, Animated, Vibration } from "react-native";
import dayjs from "dayjs";
import he from "dayjs/locale/he"; // ✅ Import Hebrew locale
import { AntDesign } from "@expo/vector-icons";

dayjs.locale(he); // ✅ Set dayjs to use Hebrew

const { width } = Dimensions.get("window");
const ITEM_WIDTH = 60;
const ITEM_MARGIN = 5;
const TOTAL_ITEM_WIDTH = 70;
const CENTER_POINT = width / 2;

const HorizontalDateSelector = ({ onDateSelect, monthOffset, setMonthOffset }) => {
    const [selectedDate, setSelectedDate] = useState(dayjs().format("YYYY-MM-DD"));
    const [contentWidth, setContentWidth] = useState(0);
    const listRef = useRef(null);
    const animatedValue = useRef(new Animated.Value(1)).current;
    const monthFadeAnim = useRef(new Animated.Value(1)).current;

    // 🔹 Animated Values for Press Effects
    const leftArrowScale = useRef(new Animated.Value(1)).current;
    const rightArrowScale = useRef(new Animated.Value(1)).current;
    const dateScale = useRef(new Animated.Value(1)).current;

    // Generate full month days dynamically
    const generateDays = () => {
        const startOfMonth = dayjs().add(monthOffset, "month").startOf("month");
        const daysInMonth = startOfMonth.daysInMonth();
        return Array.from({ length: daysInMonth }, (_, i) => startOfMonth.add(i, "day").format("YYYY-MM-DD"));
    };

    const days = generateDays();

    // Function to calculate scroll position
    const calculateScrollPosition = (index) => {
        const afterItemsWidth = index * TOTAL_ITEM_WIDTH;
        let scrollToPosition = afterItemsWidth - CENTER_POINT;
        if (index !== 0) {
            scrollToPosition += 35;
        }
        return Math.max(0, Math.min(scrollToPosition, contentWidth - width));
    };

    // Auto-scroll to the selected date when it changes
    useEffect(() => {
        const index = days.findIndex((day) => day === selectedDate);
        if (listRef.current && index !== -1) {
            listRef.current.scrollToOffset({
                offset: calculateScrollPosition(index),
                animated: true,
            });
        }
    }, [selectedDate, contentWidth]);

    // 🔹 Handle Date Selection with Animation + Vibration
    const handleDateSelect = (date, index) => {

        Animated.sequence([
            Animated.timing(dateScale, {
                toValue: 0.9,
                duration: 50,
                useNativeDriver: true,
            }),
            Animated.timing(dateScale, {
                toValue: 1.1,
                duration: 100,
                useNativeDriver: true,
            }),
            Animated.timing(dateScale, {
                toValue: 1,
                duration: 50,
                useNativeDriver: true,
            }),
        ]).start(() => {
            setSelectedDate(date);
            onDateSelect(date);
            listRef.current?.scrollToOffset({
                offset: calculateScrollPosition(index),
                animated: true,
            });
        });
    };

    // 🔹 Handle Month Change with Animation + Vibration
    const changeMonth = (direction, scaleAnim) => {
        Vibration.vibrate([3, 7]); // ✅ Short + slightly stronger

        Animated.timing(scaleAnim, {
            toValue: 0.85,
            duration: 100,
            useNativeDriver: true,
        }).start(() => {
            setMonthOffset((prev) => prev + direction);

            const newMonthDate = dayjs().add(monthOffset + direction, "month").startOf("month");
            const currentMonth = dayjs().month();
            const selectedMonth = newMonthDate.month();

            if (selectedMonth === currentMonth) {
                setSelectedDate(dayjs().format("YYYY-MM-DD"));
                onDateSelect(dayjs().format("YYYY-MM-DD"));
            } else {
                setSelectedDate(newMonthDate.format("YYYY-MM-DD"));
                onDateSelect(newMonthDate.format("YYYY-MM-DD"));
            }

            Animated.timing(scaleAnim, {
                toValue: 1,
                duration: 100,
                useNativeDriver: true,
            }).start();
        });
    };

    return (
        <View className="containerLtr">
            {/* Header with Animated Month Title */}
            <View className="flex-row items-center justify-between py-6 px-4">
                <Animated.View style={{ transform: [{ scale: rightArrowScale }] }}>
                    <Pressable onPress={() => changeMonth(-1, rightArrowScale)}>
                        <AntDesign name="arrowright" size={24} color="#333" />
                    </Pressable>
                </Animated.View>

                <Animated.Text
                    className="text-lg font-semibold text-center"
                    style={{ opacity: monthFadeAnim }}
                >
                    {dayjs().add(monthOffset, "month").format("MMMM YYYY")}
                </Animated.Text>

                <Animated.View style={{ transform: [{ scale: leftArrowScale }] }}>
                    <Pressable onPress={() => changeMonth(1, leftArrowScale)}>
                        <AntDesign name="arrowleft" size={24} color="#333" />
                    </Pressable>
                </Animated.View>
            </View>

            {/* Horizontal Date List */}
            <FlatList
                ref={listRef}
                data={days}
                horizontal
                keyExtractor={(item) => item}
                showsHorizontalScrollIndicator={false}
                getItemLayout={(data, index) => ({
                    length: TOTAL_ITEM_WIDTH,
                    offset: TOTAL_ITEM_WIDTH * index,
                    index,
                })}
                onContentSizeChange={(w) => setContentWidth(w)}
                renderItem={({ item, index }) => {
                    const isSelected = item === selectedDate;
                    const isPastDate = dayjs(item).isBefore(dayjs(), "day"); // ✅ Check if date is in the past

                    return (
                        <Pressable onPress={() => handleDateSelect(item, index)}>
                            <Animated.View
                                style={{
                                    width: ITEM_WIDTH,
                                    borderRadius: 10,
                                    paddingVertical: 10,
                                    alignItems: "center",
                                    backgroundColor: isSelected ? "#0866ff" : "#e5e5e5",
                                    marginHorizontal: ITEM_MARGIN,
                                    transform: [{ scale: isSelected ? dateScale : 1 }],
                                }}
                            >
                                <Text
                                    style={{
                                        fontSize: 16,
                                        fontWeight: "bold",
                                        color: isSelected ? "white" : isPastDate ? "#ccc" : "black",
                                    }}
                                >
                                    {dayjs(item).format("DD")}
                                </Text>
                                <Text
                                    style={{
                                        fontSize: 12,
                                        color: isSelected ? "white" : isPastDate ? "#ccc" : "gray",
                                    }}
                                >
                                    {dayjs(item).format("dddd")}
                                </Text>
                            </Animated.View>
                        </Pressable>
                    );
                }}
            />
        </View>
    );
};

export default HorizontalDateSelector;
