import { Image, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import React from "react";
import { MaterialCommunityIcons } from "@expo/vector-icons";
import logoImg from "../../assets/images/logo.png"; // ✅ Add your logo here

const Header = ({
  setShowNotification,
  setShowFavouriteModal,
}: {
  setShowNotification: React.Dispatch<React.SetStateAction<boolean>>;
  setShowFavouriteModal: React.Dispatch<React.SetStateAction<boolean>>;
}) => {
  return (
    <View className="flex-row items-center justify-between py-3 px-4   " style={styles.headerContainer}>
      {/* Notification Button - Left Side */}
      <TouchableOpacity
        style={styles.iconButton}
        onPress={() => setShowNotification(true)}
      >
        <MaterialCommunityIcons name="bell-outline" size={30} color="#009281" />
        <View style={styles.notificationBadge} />
      </TouchableOpacity>

      {/* Logo in Center */}
      <View style={styles.logoContainer}>
        <Image source={logoImg} style={styles.logo} resizeMode="contain" />
      </View>

      {/* Favorites Button - Right Side */}
      <TouchableOpacity
        style={styles.iconButton}
        onPress={() => setShowFavouriteModal(true)}
      >
        <MaterialCommunityIcons name="heart-outline" size={30} color="#009281" />
      </TouchableOpacity>
    </View>
  );
};

export default Header;

const styles = StyleSheet.create({
  headerContainer: {
   
    shadowColor: "#000", // ✅ Adds a shadow for better visibility
    shadowOpacity: 0.1,
    shadowRadius: 5,
    shadowOffset: { width: 0, height: 5 },
    elevation: 5, // ✅ For Android shadow
    backgroundColor:'#FFF'
  },
  logoContainer: {
    flex: 1,
    alignItems: "center",
    
  },
  logo: {
    height: 35,
    
  },
  iconButton: {
    
  },
  notificationBadge: {
    position: "absolute",
    top: -4,
    right: -4,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#b91c1c",
  },
});
