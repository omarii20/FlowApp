import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet } from "react-native";
import { topDoctorData } from "@/constants/data";
import DoctorCard from "../ui/DoctorCard";
import Animated, { useSharedValue, useAnimatedStyle } from "react-native-reanimated";
import HorizontalDateSelector from "./HorizontalDateSelector";
import dayjs from "dayjs";
import ShimmerPlaceholder from "react-native-shimmer-placeholder";
import { LinearGradient } from "expo-linear-gradient";

const TopDoctor = () => {
  const [activeDate, setActiveDate] = useState(dayjs().format("YYYY-MM-DD"));
  const [monthOffset, setMonthOffset] = useState(0);
  const opacity = useSharedValue(1);
  const [loading, setLoading] = useState(true);
  const [filteredData, setFilteredData] = useState([]);

  useEffect(() => {
    setLoading(true);

    setTimeout(() => {
      const updatedDoctors = topDoctorData.filter(({ date }) =>
        dayjs(date).format("YYYY-MM-DD") === activeDate
      );
      setFilteredData(updatedDoctors);
      setLoading(false);
    }, 1000);
  }, [activeDate, monthOffset]);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
  }));

  return (
    <View className="block">
      {/* Date Selector Component */}
      <HorizontalDateSelector 
        onDateSelect={setActiveDate} 
        monthOffset={monthOffset} 
        setMonthOffset={setMonthOffset} 
      />

      {/* Animated List of Filtered Doctors */}
      <Animated.View style={[animatedStyle]} className="mt-2 px-3">
        {loading ? (
          // Show shimmer placeholders with full layout
          Array.from({ length: 5 }).map((_, idx) => (
            <View key={idx} style={styles.cardContainer}>
              {/* Doctor Image Placeholder */}
              <ShimmerPlaceholder
                LinearGradient={LinearGradient}
                style={styles.imagePlaceholder}
              />

              <View style={styles.textContainer}>
                {/* Doctor Name Placeholder */}
                <ShimmerPlaceholder
                  LinearGradient={LinearGradient}
                  style={styles.textPlaceholder}
                />
                {/* Medical Name Placeholder */}
                <ShimmerPlaceholder
                  LinearGradient={LinearGradient}
                  style={[styles.textPlaceholder, { width: "50%" }]}
                />
                {/* Available Time Placeholder */}
                <ShimmerPlaceholder
                  LinearGradient={LinearGradient}
                  style={[styles.textPlaceholder, { width: "40%" }]}
                />
              </View>

              {/* Join Button Placeholder */}
              <ShimmerPlaceholder
                LinearGradient={LinearGradient}
                style={styles.buttonPlaceholder}
              />
            </View>
          ))
        ) : filteredData.length > 0 ? (
          filteredData.map(({ ...props }, idx) => <DoctorCard {...props} key={idx} />)
        ) : (
          <Text className="text-center text-bodyText pt-4">אין קבוצות זמינות</Text>
        )}
      </Animated.View>
    </View>
  );
};

export default TopDoctor;

// Styles for shimmer placeholders
const styles = StyleSheet.create({
  cardContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#f1f1f1",
    borderRadius: 10,
    padding: 10,
    marginTop: 20,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 1 },
    elevation: 2,
    minHeight:90
  },
  imagePlaceholder: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  textContainer: {
    flex: 1,
  },
  textPlaceholder: {
    height: 12,
    borderRadius: 5,
    marginBottom: 6,
    width: "80%",
  },
  buttonPlaceholder: {
    width: 80,
    height: 30,
    borderRadius: 5,
  },
});
