import { Pressable, StyleSheet, Text } from "react-native";
import React from "react";
import { router } from "expo-router";

type PropsType = {
  link: string;
  text: string;
};

const BookButton = ({ link, text }: PropsType) => {
  return (
    <Pressable
      onPress={() => router.push(link)}
      className=" text-primaryColor border-t-[1px] border-x-[1px] border-b-[2px] border-primaryColor px-3 py-2 rounded-lg "
    >
      <Text className="">
        {text}
      </Text>
    </Pressable>
  );
};

export default BookButton;

const styles = StyleSheet.create({});
