import React from "react";
import { Image, Text, View, TouchableOpacity } from "react-native";
import { AntDesign, Entypo } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import BookButton from "../BookButton";
const DoctorCard = ({
  img,
  name,
  department,
  medicalName,
  rating,
  availableTime,
  fee,
}) => {
  const router = useRouter();

  return (
    <View className="p-3 bg-white rounded-xl w-full mt-4">
      <View className="flex flex-row w-full justify-between items-center">
        <View className="flex flex-row justify-start items-center">
          <View className="bg-secondaryBg rounded-lg overflow-hidden rtl:mr-6">
            <Image source={img} />
          </View>
          <View className="items-start">
            <Text
              onPress={() => router.push("/DoctorProfile")}
              className="text-base font-medium text-right"
            >
              {name}
            </Text>
            <Text className="py-2 text-right">
              <Text className="text-[12px] text-bodyText">{medicalName}</Text>
              <Entypo name="dot-single" />
            </Text>
            <Text className="text-[12px] text-right">
              <Text className="text-primaryColor">
                {availableTime} <AntDesign name="clockcircle" />
              </Text>
            </Text>
          </View>
        </View>
       
        <BookButton link="/Appoinment" text="הצטרפות" />
      
      </View>
    </View>
  );
};

export default DoctorCard;
