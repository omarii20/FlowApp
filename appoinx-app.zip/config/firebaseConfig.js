import { firebase } from "@react-native-firebase/app";
import messaging from "@react-native-firebase/messaging";
import auth from "@react-native-firebase/auth";
import * as Notifications from "expo-notifications";

// ✅ Firebase Configuration
const firebaseConfig = {
  apiKey: "AlzaSYb-Sp208SHLKrB5DXsgidX_9ziLtYYpnU",
  authDomain: "flowapp-e47ae.firebaseapp.com",
  projectId: "flowapp-e47ae",
  storageBucket: "flowapp-e47ae.appspot.com",
  messagingSenderId: "123253505121",
  appId: "1:123253505121:android:a62f4807e076c2d3e1fe20"
};

// ✅ Initialize Firebase only if not already initialized
try {
  if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
    console.log("✅ Firebase Initialized Successfully");
  }
} catch (error) {
  console.error("❌ Firebase Initialization Failed:", error);
}
// ✅ Request Permission and Get Expo Push Token
export async function registerForPushNotificationsAsync() {
  try {
    const { status } = await Notifications.getPermissionsAsync();
    let finalStatus = status;

    if (status !== "granted") {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    if (finalStatus !== "granted") {
      console.warn("⚠️ Push Notification Permission Denied.");
      return;
    }

    // ✅ Get Expo Push Token (only for Expo projects)
    const token = (await Notifications.getExpoPushTokenAsync()).data;
    console.log("✅ Expo Push Token:", token);
    return token;
  } catch (error) {
    console.error("❌ Error getting Expo Push Token:", error);
  }
}

// ✅ Get FCM Token
export async function getFCMToken() {
  try {
    const token = await messaging().getToken();
    if (token) {
      console.log("✅ FCM Token:", token);
      return token;
    } else {
      console.warn("⚠️ No FCM Token Found.");
    }
  } catch (error) {
    console.error("❌ Error getting FCM Token:", error);
  }
}

// ✅ Handle Incoming Notifications
// ✅ Handle Incoming Notifications with Debugging
export function setupPushNotificationListeners() {
  console.log("🔔 Setting up push notification listeners...");

  // Set notification handler
  Notifications.setNotificationHandler({
    handleNotification: async (notification) => {
      console.log("📩 Foreground Notification Received:", JSON.stringify(notification, null, 2));
      return {
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: false,
      };
    },
  });

  // ✅ Handle notification when app is open (Foreground)
  messaging().onMessage(async (remoteMessage) => {
    console.log("📩 Foreground Push Notification Data:", JSON.stringify(remoteMessage, null, 2));
    
    await Notifications.scheduleNotificationAsync({
      content: {
        title: remoteMessage.notification?.title || "📢 Notification",
        body: remoteMessage.notification?.body || "📨 You have a new message!",
        data: remoteMessage.data || {},
      },
      trigger: null, // Show instantly
    });
  });

  // ✅ Handle notification when app is in background but opened
  messaging().onNotificationOpenedApp((remoteMessage) => {
    console.log("📤 App Opened from Background Notification:", JSON.stringify(remoteMessage, null, 2));
  });

  // ✅ Handle notification when app is quit and opened from a notification
  messaging()
    .getInitialNotification()
    .then((remoteMessage) => {
      if (remoteMessage) {
        console.log("📌 Notification Caused App to Open from Quit State:", JSON.stringify(remoteMessage, null, 2));
      }
    });

  // ✅ Handle background push notifications
  messaging().setBackgroundMessageHandler(async (remoteMessage) => {
    console.log("📩 Background Notification Received:", JSON.stringify(remoteMessage, null, 2));
  });

  console.log("✅ Push Notification Listeners Initialized Successfully!");
}


// ✅ Export Firebase Modules
export { messaging, auth };
